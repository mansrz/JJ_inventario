Fuente de informacion para cambiar el color: 
http://qt.developpez.com/doc/4.6/stylesheet-examples/

Pasos para hacer ejectuble:
http://www.logix4u.net/component/content/article/27-tutorials/44-how-to-create-windows-executable-exe-from-python-script
